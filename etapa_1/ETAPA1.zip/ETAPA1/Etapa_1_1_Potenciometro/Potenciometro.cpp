#include "Arduino.h"
#include "Potenciometro.h"

const int PIN_POT = A0;

namespace Potenciometro 
{

    void inicializar() 
    {
        pinMode(PIN_POT, INPUT);
    }

    int leer() {
        return analogRead(PIN_POT);
    }

}
