#ifndef   POTENCIOMETRO_H
#define   POTENCIOMETRO_H

namespace Potenciometro 
{
    void inicializar();
    int leer();
}

#endif
