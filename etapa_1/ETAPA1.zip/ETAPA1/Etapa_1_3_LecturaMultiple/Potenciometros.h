#ifndef POTENCIOMETROS_H
#define POTENCIOMETROS_H

namespace Potenciometros 
{
    void inicializar();
    int leerPot0();
    int leerPot1();
    int leerPot2();
    int leerPot3();
    int leerPot4();
}

#endif
