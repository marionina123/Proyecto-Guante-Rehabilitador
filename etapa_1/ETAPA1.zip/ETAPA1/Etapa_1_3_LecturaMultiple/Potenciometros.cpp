#include "Arduino.h"
#include "Potenciometros.h"

const int PIN_POT_0 = A0;
const int PIN_POT_1 = A1;
const int PIN_POT_2 = A2;
const int PIN_POT_3 = A3;
const int PIN_POT_4 = A4;

namespace Potenciometros 
{

    void inicializar() 
    {
        pinMode(PIN_POT_0, INPUT);
        pinMode(PIN_POT_1, INPUT);
        pinMode(PIN_POT_2, INPUT);
        pinMode(PIN_POT_3, INPUT);
        pinMode(PIN_POT_4, INPUT);
    }

    int leerPot0() 
    {
        return analogRead(PIN_POT_0);
    }

    int leerPot1() 
    {
        return analogRead(PIN_POT_1);
    }

    int leerPot2() 
    {
        return analogRead(PIN_POT_2);
    }

    int leerPot3() 
    {
        return analogRead(PIN_POT_3);
    }

    int leerPot4() 
    {
        return analogRead(PIN_POT_4);
    }

}
