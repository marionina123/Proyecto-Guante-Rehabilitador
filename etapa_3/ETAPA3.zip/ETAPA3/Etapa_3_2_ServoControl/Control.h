#ifndef CONTROL_H
#define CONTROL_H

namespace Control {
    void inicializar();
    void mover(int angulo);
}

#endif
