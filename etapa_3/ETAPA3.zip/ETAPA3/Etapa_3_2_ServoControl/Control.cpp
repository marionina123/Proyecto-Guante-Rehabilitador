#include <Servo.h>
#include "Control.h"

namespace Control {
    Servo servo;
    const int PIN_SERVO = 9;

    void inicializar() {
        servo.attach(PIN_SERVO);
    }

    void mover(int angulo) {
        servo.write(angulo);
    }
}
