#include "Arduino.h"
#include "Poten.h"

const int PIN_POT = A0;

namespace Poten {
    void inicializar() {
        pinMode(PIN_POT, INPUT);
    }

    int leer() {
        return analogRead(PIN_POT);
    }
}
