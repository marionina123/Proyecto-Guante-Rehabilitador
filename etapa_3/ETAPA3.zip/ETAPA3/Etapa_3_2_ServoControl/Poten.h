#ifndef POTEN_H
#define POTEN_H

namespace Poten {
    void inicializar();
    int leer();
}

#endif
