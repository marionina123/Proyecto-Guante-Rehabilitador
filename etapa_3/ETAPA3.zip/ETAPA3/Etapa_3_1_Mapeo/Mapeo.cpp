#include "Arduino.h"
#include "Mapeo.h"

const int PIN_POT = A0;

namespace Mapeo {
    void inicializar() {
        pinMode(PIN_POT, INPUT);
    }

    int leer() {
        return analogRead(PIN_POT);
    }
}
