#ifndef   POTENCIOMETRO_H
#define   POTENCIOMETRO_H

namespace Mapeo {
    void inicializar();
    int leer();
}

#endif
