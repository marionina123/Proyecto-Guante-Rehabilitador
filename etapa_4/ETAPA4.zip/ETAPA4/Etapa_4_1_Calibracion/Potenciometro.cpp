#include "Arduino.h"
#include "Potenciometro.h"

const int PINES_POT[5] = {A0, A1, A2, A3, A4};

namespace Potenciometro {
    void inicializar() {
        for (int i = 0; i < 5; i++) {
            pinMode(PINES_POT[i], INPUT);
        }
    }

    int leer(int index) {
        if (index >= 0 && index < 5) {
            return analogRead(PINES_POT[index]);
        } else {
            return 0;
        }
    }
}
