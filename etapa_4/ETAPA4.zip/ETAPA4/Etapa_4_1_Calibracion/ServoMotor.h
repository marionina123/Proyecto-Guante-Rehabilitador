#ifndef SERVO_MOTOR_H
#define SERVO_MOTOR_H

namespace ServoMotor {
    void inicializar();
    void mover(int index, int angulo);
}

#endif
