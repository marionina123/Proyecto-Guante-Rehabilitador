#include <Servo.h>
#include "ServoControl.h"

namespace ServoControl {
    const int NUM_SERVOS = 5;
    const int PINES_SERVOS[NUM_SERVOS] = {3, 5, 6, 9, 10};
    Servo servos[NUM_SERVOS];

    void inicializar() {
        for (int i = 0; i < NUM_SERVOS; i++) {
            servos[i].attach(PINES_SERVOS[i]);
        }
    }
    
    void mover(int index, int angulo) {
        if (index >= 0 && index < NUM_SERVOS) {
            servos[index].write(angulo);
        }
    }
}
