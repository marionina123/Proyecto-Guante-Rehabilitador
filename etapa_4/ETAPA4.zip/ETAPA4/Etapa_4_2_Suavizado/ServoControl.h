#ifndef SERVO_CONTROL_H
#define SERVO_CONTROL_H

namespace ServoControl {
    void inicializar();
    void mover(int index, int angulo);
}

#endif
