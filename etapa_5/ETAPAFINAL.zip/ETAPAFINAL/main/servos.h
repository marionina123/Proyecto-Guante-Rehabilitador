#ifndef SERVOS_H
#define SERVOS_H

#include <Arduino.h>

// Inicializa servos
void inicializarServos(const int* pines, int cantidad);

// Actualiza posiciones según potenciómetros y rango seleccionado
void actualizarServos(int opcionRango);

#endif
