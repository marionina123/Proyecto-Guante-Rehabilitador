#include "potenciometros.h"

// Variables estáticas que almacenan configuración y estado
static const int* pinesPots;
static int cantidadPots;
static int* valoresBrutos;
static float* valoresSuavizados;

const float coefSuavizado = 0.1; // Coeficiente del filtro de suavizado (promedio exponencial)

void inicializarPots(const int* pines, int cantidad) 
{
  // Asigna punteros y reserva memoria para valores
  pinesPots = pines;
  cantidadPots = cantidad;
  valoresBrutos = new int[cantidadPots];
  valoresSuavizados = new float[cantidadPots];

  // Inicializa todos los pines como entradas y valores en cero
  for (int i = 0; i < cantidadPots; i++) 
  {
    valoresBrutos[i] = 0;
    valoresSuavizados[i] = 0;
    pinMode(pinesPots[i], INPUT);
  }
}

void leerYSuavizarPots() {
  // Aplica suavizado exponencial a cada potenciómetro
  for (int i = 0; i < cantidadPots; i++) 
  {
    valoresBrutos[i] = analogRead(pinesPots[i]);
    valoresSuavizados[i] = coefSuavizado * valoresBrutos[i] + 
                           (1 - coefSuavizado) * valoresSuavizados[i];
  }
}

float obtenerValorSuavizado(int indice) 
{
  // Retorna valor suavizado del potenciómetro especificado
  if (indice < 0 || indice >= cantidadPots) return 0;
  return valoresSuavizados[indice];
}
