#include "servos.h"
#include <Servo.h>
#include "potenciometros.h"

// Variables globales internas
static const int* pinesServos;
static int cantidadServos;
static Servo* servos;
static int* ultimoAngulo;   // Guarda la última posición enviada
static int* anguloActual;   // Guarda la posición actual (con rampa de aceleración)

// Parámetros de comportamiento
const int umbralHisteresis = 3;     // Evita pequeños movimientos innecesarios
const int pasoMaximo = 2;           // Incremento máximo por ciclo (suaviza movimiento)
const int umbralSincronizado = 50;  // Activación del modo sincronizado si el sexto potenciómetro pasa este valor

// Tabla que define el ángulo máximo según la opción elegida (del 1 al 6)
const int tablaRangos[] = {30, 60, 90, 120, 150, 180};

void inicializarServos(const int* pines, int cantidad) 
{
  pinesServos = pines;
  cantidadServos = cantidad;

  // Reserva memoria para los objetos y estados
  servos = new Servo[cantidadServos];
  ultimoAngulo = new int[cantidadServos];
  anguloActual = new int[cantidadServos];

  // Configura servos y valores iniciales
  for (int i = 0; i < cantidadServos; i++) 
  {
    servos[i].attach(pinesServos[i]);
    ultimoAngulo[i] = 0;
    anguloActual[i] = 0;
    servos[i].write(0); // Posición inicial
  }
}

void actualizarServos(int opcionRango) 
{
  int rangoMaximo = tablaRangos[constrain(opcionRango, 1, 6) - 1];

  // Verifica si se debe usar el control sincronizado (con el sexto potenciómetro)
  int valorSincronizado = obtenerValorSuavizado(5);
  bool modoSincronizado = valorSincronizado > umbralSincronizado;

  for (int i = 0; i < cantidadServos; i++) 
  {
    // Selecciona fuente de control (individual o global)
    int valorPot = modoSincronizado ? valorSincronizado : obtenerValorSuavizado(i);

    // Convierte valor analógico en ángulo dentro del rango seleccionado
    int anguloObjetivo = map(valorPot, 0, 1023, 0, rangoMaximo);
    anguloObjetivo = constrain(anguloObjetivo, 0, rangoMaximo);

    // Aplica rampa de velocidad: no permite saltos bruscos
    if (anguloActual[i] < anguloObjetivo) 
    {
      anguloActual[i] += pasoMaximo;
      if (anguloActual[i] > anguloObjetivo) anguloActual[i] = anguloObjetivo;
    } else if (anguloActual[i] > anguloObjetivo) 
    {
      anguloActual[i] -= pasoMaximo;
      if (anguloActual[i] < anguloObjetivo) anguloActual[i] = anguloObjetivo;
    }

    // Aplica histéresis: solo mueve si hay diferencia significativa
    if (abs(anguloActual[i] - ultimoAngulo[i]) >= umbralHisteresis) 
    {
      servos[i].write(anguloActual[i]);
      ultimoAngulo[i] = anguloActual[i];
    }
  }
}
