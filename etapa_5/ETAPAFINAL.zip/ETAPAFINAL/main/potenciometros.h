#ifndef POTENCIOMETROS_H
#define POTENCIOMETROS_H

#include <Arduino.h>

// Inicializa potenciómetros
void inicializarPots(const int* pines, int cantidad);

// Lee valores analógicos y aplica filtro de suavizado
void leerYSuavizarPots();

// Retorna el valor suavizado de un potenciómetro específico
float obtenerValorSuavizado(int indice);

#endif
