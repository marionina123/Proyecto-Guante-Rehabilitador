#include "potenciometros.h"

static const int* pinesPots;
static int cantidadPots;
static int* valoresPotsBrutos;
static float* valoresPotsSuavizados;

static const float constanteAlfa = 0.1;

void inicializarPots(const int* pines, int cantidad) 
{
  pinesPots = pines;
  cantidadPots = cantidad;
  valoresPotsBrutos = new int[cantidadPots];
  valoresPotsSuavizados = new float[cantidadPots];

  for (int i = 0; i < cantidadPots; i++) 
  {
    valoresPotsSuavizados[i] = 0;
  }

  for (int i = 0; i < cantidadPots; i++) 
  {
    pinMode(pinesPots[i], INPUT);
  }
}

void leerYSuavizarPots() 
{
  for (int i = 0; i < cantidadPots; i++) 
  {
    valoresPotsBrutos[i] = analogRead(pinesPots[i]);
    valoresPotsSuavizados[i] = constanteAlfa * valoresPotsBrutos[i] + (1 - constanteAlfa) * valoresPotsSuavizados[i];
  }
}

float obtenerValorSuavizado(int indice) 
{
  if (indice < 0 || indice >= cantidadPots) return 0;
  return valoresPotsSuavizados[indice];
}
