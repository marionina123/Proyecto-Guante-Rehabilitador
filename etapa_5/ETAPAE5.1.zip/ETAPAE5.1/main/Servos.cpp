#include "servos.h"
#include <Servo.h>

static const int* pinesServos;
static int cantidadServos;
static Servo* servos;
static int* ultimoAngulo;
static int* anguloActual;
static int* anguloObjetivo;

static const int umbralHisteresis = 3;
static const int pasoMaximo = 2;

// Índice del potenciómetro maestro en el arreglo completo (dedos + maestro)
static const int indicePotMaestro = 5;

extern float obtenerValorSuavizado(int indice);

void inicializarServos(const int* pines, int cantidad) 
{
  pinesServos = pines;
  cantidadServos = cantidad;
  servos = new Servo[cantidadServos];
  ultimoAngulo = new int[cantidadServos];
  anguloActual = new int[cantidadServos];
  anguloObjetivo = new int[cantidadServos];

  for (int i = 0; i < cantidadServos; i++) 
  {
    ultimoAngulo[i] = 0;
    anguloActual[i] = 0;
    anguloObjetivo[i] = 0;
    servos[i].attach(pinesServos[i]);
    servos[i].write(0);
  }
}

void actualizarServos() 
{
  // Leer valor suavizado del potenciómetro maestro
  float valorPotMaestro = obtenerValorSuavizado(indicePotMaestro);
  int anguloMaestro = map((int)valorPotMaestro, 0, 1023, 0, 180);
  anguloMaestro = constrain(anguloMaestro, 0, 180);

  if (anguloMaestro > 0) {
    // Control conjunto: todos los servos se mueven al mismo ángulo del potenciómetro maestro
    for (int i = 0; i < cantidadServos; i++) 
    {
      if (anguloActual[i] < anguloMaestro) 
      {
        anguloActual[i] += pasoMaximo;
        if (anguloActual[i] > anguloMaestro) anguloActual[i] = anguloMaestro;
      } else if (anguloActual[i] > anguloMaestro) 
      {
        anguloActual[i] -= pasoMaximo;
        if (anguloActual[i] < anguloMaestro) anguloActual[i] = anguloMaestro;
      }

      if (abs(anguloActual[i] - ultimoAngulo[i]) >= umbralHisteresis) 
      {
        servos[i].write(anguloActual[i]);
        ultimoAngulo[i] = anguloActual[i];
      }
    }
  } else {
    // Control individual: cada servo se mueve según su potenciómetro correspondiente
    for (int i = 0; i < cantidadServos; i++) 
    {
      float valorSuavizado = obtenerValorSuavizado(i);
      anguloObjetivo[i] = map((int)valorSuavizado, 0, 1023, 0, 180);
      anguloObjetivo[i] = constrain(anguloObjetivo[i], 0, 180);

      if (anguloActual[i] < anguloObjetivo[i]) 
      {
        anguloActual[i] += pasoMaximo;
        if (anguloActual[i] > anguloObjetivo[i]) anguloActual[i] = anguloObjetivo[i];
      } else if (anguloActual[i] > anguloObjetivo[i]) 
      {
        anguloActual[i] -= pasoMaximo;
        if (anguloActual[i] < anguloObjetivo[i]) anguloActual[i] = anguloObjetivo[i];
      }

      if (abs(anguloActual[i] - ultimoAngulo[i]) >= umbralHisteresis) 
      {
        servos[i].write(anguloActual[i]);
        ultimoAngulo[i] = anguloActual[i];
      }
    }
  }
}
