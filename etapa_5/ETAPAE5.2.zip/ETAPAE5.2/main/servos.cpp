#include "servos.h"
#include <Servo.h>
#include "potenciometros.h"

static const int* pinesServos;
static int cantidadServos;
static Servo* servos;
static int* ultimoAngulo;
static int* anguloActual;

const int umbralHisteresis = 3;    // Para evitar movimientos pequeños innecesarios
const int pasoMaximo = 2;          // Máximo cambio por ciclo
const int umbralSincronizado = 50; // Valor mínimo para activar el modo sincronizado

// Tabla de rangos según opción
const int tablaRangos[] = {30, 60, 90, 120, 150, 180};

void inicializarServos(const int* pines, int cantidad) {
  pinesServos = pines;
  cantidadServos = cantidad;
  servos = new Servo[cantidadServos];
  ultimoAngulo = new int[cantidadServos];
  anguloActual = new int[cantidadServos];

  for (int i = 0; i < cantidadServos; i++) {
    servos[i].attach(pinesServos[i]);
    ultimoAngulo[i] = 0;
    anguloActual[i] = 0;
    servos[i].write(0);
  }
}

void actualizarServos(int opcionRango) {
  int rangoMaximo = tablaRangos[constrain(opcionRango, 1, 6) - 1];
  int valorSincronizado = obtenerValorSuavizado(5); // Último pot para control global
  bool modoSincronizado = valorSincronizado > umbralSincronizado;

  for (int i = 0; i < cantidadServos; i++) {
    int valorPot = modoSincronizado ? valorSincronizado : obtenerValorSuavizado(i);
    int anguloObjetivo = map(valorPot, 0, 1023, 0, rangoMaximo);
    anguloObjetivo = constrain(anguloObjetivo, 0, rangoMaximo);

    // Aplicar rampa de velocidad
    if (anguloActual[i] < anguloObjetivo) {
      anguloActual[i] += pasoMaximo;
      if (anguloActual[i] > anguloObjetivo) anguloActual[i] = anguloObjetivo;
    } else if (anguloActual[i] > anguloObjetivo) {
      anguloActual[i] -= pasoMaximo;
      if (anguloActual[i] < anguloObjetivo) anguloActual[i] = anguloObjetivo;
    }

    // Histéresis para evitar micromovimientos
    if (abs(anguloActual[i] - ultimoAngulo[i]) >= umbralHisteresis) {
      servos[i].write(anguloActual[i]);
      ultimoAngulo[i] = anguloActual[i];
    }
  }
}
