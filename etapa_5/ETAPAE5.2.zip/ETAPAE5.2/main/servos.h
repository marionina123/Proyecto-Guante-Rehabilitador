#ifndef SERVOS_H
#define SERVOS_H

#include <Arduino.h>

void inicializarServos(const int* pines, int cantidad);
void actualizarServos(int opcionRango);

#endif
