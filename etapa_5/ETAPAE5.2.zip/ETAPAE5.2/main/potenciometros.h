#ifndef POTENCIOMETROS_H
#define POTENCIOMETROS_H

#include <Arduino.h>

void inicializarPots(const int* pines, int cantidad);
void leerYSuavizarPots();
float obtenerValorSuavizado(int indice);

#endif
