#include "potenciometros.h"

static const int* pinesPots;
static int cantidadPots;
static int* valoresBrutos;
static float* valoresSuavizados;

const float coefSuavizado = 0.1;

void inicializarPots(const int* pines, int cantidad) {
  pinesPots = pines;
  cantidadPots = cantidad;
  valoresBrutos = new int[cantidadPots];
  valoresSuavizados = new float[cantidadPots];

  for (int i = 0; i < cantidadPots; i++) {
    valoresBrutos[i] = 0;
    valoresSuavizados[i] = 0;
    pinMode(pinesPots[i], INPUT);
  }
}

void leerYSuavizarPots() {
  for (int i = 0; i < cantidadPots; i++) {
    valoresBrutos[i] = analogRead(pinesPots[i]);
    valoresSuavizados[i] = coefSuavizado * valoresBrutos[i] + (1 - coefSuavizado) * valoresSuavizados[i];
  }
}

float obtenerValorSuavizado(int indice) {
  if (indice < 0 || indice >= cantidadPots) return 0;
  return valoresSuavizados[indice];
}
