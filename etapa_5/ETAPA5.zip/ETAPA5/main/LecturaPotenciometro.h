#ifndef LECTURA_POTENCIOMETRO_H
#define LECTURA_POTENCIOMETRO_H

class LecturaPotenciometro {
  public:
    LecturaPotenciometro(int pin);
    void calibrar(int minEntrada, int maxEntrada);
    int leer();
    int mapearA(int salidaMin, int salidaMax);

  private:
    int pinAnalogico;
    int entradas[5];
    int indice;
    int minimoEntrada;
    int maximoEntrada;
};

#endif
