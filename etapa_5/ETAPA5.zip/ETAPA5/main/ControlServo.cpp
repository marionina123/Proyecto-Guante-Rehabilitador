#include "ControlServo.h"

ControlServo::ControlServo(int pin) {
  pinPWM = pin;
  anguloActual = 0;
  deltaMax = 5;
  umbralHisteresis = 2;
  servo.attach(pinPWM);
  servo.write(anguloActual);
}

void ControlServo::configurarVelocidadMaxima(int gradosPorCiclo) {
  deltaMax = gradosPorCiclo;
}

void ControlServo::configurarHisteresis(int umbralGrados) {
  umbralHisteresis = umbralGrados;
}

void ControlServo::moverA(int nuevoAngulo) {
  int diferencia = nuevoAngulo - anguloActual;

  if (abs(diferencia) < umbralHisteresis) {
    return; 
  }

  if (abs(diferencia) > deltaMax) {
    anguloActual += (diferencia > 0) ? deltaMax : -deltaMax;
  } else {
    anguloActual = nuevoAngulo;
  }

  servo.write(anguloActual);
}
