#include "LecturaPotenciometro.h"
#include <Arduino.h>

LecturaPotenciometro::LecturaPotenciometro(int pin) {
  pinAnalogico = pin;
  minimoEntrada = 0;
  maximoEntrada = 1023;
  indice = 0;

  for (int i = 0; i < 5; i++) {
    entradas[i] = 0;
  }
}

void LecturaPotenciometro::calibrar(int minEntrada, int maxEntrada) {
  minimoEntrada = minEntrada;
  maximoEntrada = maxEntrada;
}

int LecturaPotenciometro::leer() {
  entradas[indice] = analogRead(pinAnalogico);
  indice = (indice + 1) % 5;

  int suma = 0;
  for (int i = 0; i < 5; i++) {
    suma += entradas[i];
  }

  return suma / 5; 
}

int LecturaPotenciometro::mapearA(int salidaMin, int salidaMax) {
  int valor = leer();
  valor = constrain(valor, minimoEntrada, maximoEntrada);
  return map(valor, minimoEntrada, maximoEntrada, salidaMin, salidaMax);
}
